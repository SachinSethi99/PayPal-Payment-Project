<!--Sachin Sethi's PHP-->
<!DOCTYPE html>
<html lang="en"> <!-- The language is set to English and it is HTML-->
<head> 
<meta charset="utf-8"> 
	<title>Payment Options</title> <!--the header's title-->
	<link rel='stylesheet' href='css/form-style.css' type='text/css' /> <!--link to the css stylesheet-->
	<script src="js/credit-card-master-validation.js"></script> <!--link to the javaScript validation-->
</head>

<body onload= 'document.form1.ccnum.focus()' > 


<div id="container"> <!-- div tag called container for the title section on my html-->
	<h2>Payment Options</h2> <!--title on the page-->
	<hr style= "Border: 2px solid #C8C8C8 "/> <!-- the line underneath the title-->
</div>

<div id="container1">  <!--another div tag that holds the subheading style, postion and image postion --->
	<h3>Debit / Credit Card <div id ="masterCardimg"> <img src= "img/mastercard.png" width= "15%" height="15%" float="middle"></div> </h3> <!-- image of mastercard and subheading-->
</div>
<br><!--break tag add a row of space -->
	
<div id="container2"> <!--another div tag --->
<form name="form1" method='POST' onsubmit= "return lengthCheck(), cardnumber(), CVV()">  <!--calling a method to submit and ensure functions in javaScript are called upon-->
<ul>
<li><label><b>Card Number </b> <div id="cardNumber"></label>&nbsp;<input type='text' id='ccnum' name='ccnum'/></div></li> 
<br>	

<li><label><b>Expiry Date</b></label> <!--this the expiry date label -->
<div id = "experationDate"> <!--the div id for expiry tag to postion the name and the select boxes correctly -->
<select name='month' id='month'> <!--month id, use to get the months when inputting into the datbase -->
<option value="Month" selected>Month</option> <!--first option to show the user this box is the month -->
			<option value ="1">1</option><!--months in number format -->
			<option value ="2">2</option>
			<option value ="3">3</option>
			<option value ="4">4</option>
			<option value ="5">5</option>
			<option value ="6">6</option>
			<option value ="7">7</option>
			<option value ="8">8</option>
			<option value ="9">9</option>
			<option value ="10">10</option>
			<option value ="11">11</option>
			<option value ="12">12</option>

</select>
<select name='year' id='year'> <!--year id, the same job as the month id -->
		<option value="Year" selected>Year</option>
		<option value ="2020">2020</option><!--years shown on the select statement -->
		<option value ="2021">2021</option>
		<option value ="2022">2022</option>
		<option value ="2023">2023</option>
		<option value ="2024">2024</option>
		<option value ="2025">2025</option>
		<option value ="2026">2026</option>
		<option value ="2027">2027</option>
		<option value ="2028">2028</option>
		<option value ="2029">2029</option>
		<option value ="2030">2030</option>
</select>
</div>
</li>
<br>


<li><label> <b>Security Code</b></label><div id ="securityCode">&nbsp;<input type='text' size='4' name='seccode' id='seccode'/></div></li> <!--label for the securityCode and input size and type and id is givin for php and javaScript to get the element -->
	<div id= "sentenceInstruction"> <!--div id for css sytle and postion -->
		<p> (3-4 digit code normally on the back of your card)</p> <!--user instruction -->
	</div>

<li>&nbsp;</li>

<div>
	<button id="button" onclick="cardnumber(document.form1.ccnum), lengthCheck(document.form1.ccnum), CVV(document.form1.seccode)"> Continue </button> <!--button for user to click on, and it excute the javaScript to validate the ccnum and cvv -->
</div>
</ul>
</form>
</div>

</form>
<?php //start of php
// if the card number has bein posted run the php
if(isset($_POST['ccnum'])){
	
//enters the information into the database
$year = $_POST['year'];
$month = $_POST['month'];
$seccode = $_POST['seccode'];
// puts the date as one date 
$date = $year."-".$month."-01"; //all dates have day that begins with 1 as default 
//takes the card number, once connection is made
$cardin = $_POST['ccnum'];

//encode the inputed card number          
$ccnum = substr($cardin, -4,16); // shown as **** **** **** 1234 in the database for encryption

//connection to the sql database, to the host, username, password, and name of database
$conn = new mysqli("localhost","root","","creditcard");
	
	$sql = "SELECT MAX(`#`) as total FROM card "; //highest row number is found and stored into the database
 	$result = $conn->query($sql); //the varibles stores the query 
	if ($result-> num_rows >0){ // if the result is found  then use the fetch_assoc
		while ($row = $result->fetch_assoc()){ // fetch_assoc stores the result and stores in the database, stores the result as an array
			$cardnum=$row["total"];// row is stores in cardum in the database
		}
	}
	
	$sqli = "INSERT INTO card (`#`, ccnum, expdate, seccode) VALUES ($cardnum+1,' **** **** **** $ccnum', '$date', '$seccode')"; // add the user inputed card details into database and it inserts into those attrubutes using the values, shown at the right of VALUES
	if($conn->query($sqli)){ //if the user puts the data into the the values then it goes to the secondpage
			header("Location:secondpage.php"); //goes to the secondpage
		exit; 
	}
	else{ echo "failed";} //if not then it has failed
}
?> 
<!--end of php -->
</div>
</div>
</body>
</html> <!--end of html and webpage -->