function cardnumber()
{ //card number to check if it is a mastercard
var cardno =/^(?:5[1-5][0-9]{14})$/; //if the number begins with '5' then we know its master card, its stored in cardno 
if (ccnum.value.match(cardno)) //if the value that user has entered matches cardno then return true 
{
  return true;
}
else //if not then say its not a valid master card 
{
alert("Not Valid - Please Insert Correct Credit Card number, Not Master Card");//alert message
return false;
ccnum.focus();
}

}

function lengthCheck() //checks the length of the card number
{
  var string = document.getElementById("ccnum").value; // checks the ccnum, the text box where user enters their card details 
    var n = string.length; //n = stores the checkt the length of the string 
    document.getElementById("ccnum").innerHTML = n; //the ccnum is now stored as n
    if ((n > 16) || (n < 16)) //if the cardnumber (n) is less than or greater than 16 then return false and then say the alert and if its is 16 then return true
    {
   alert("Please Enter a 16 Digit Credit Card Number");//alert message
   return false
    }
else {

  return true;
}

}


function CVV(){ //if the sortcode has value more than 3
var a = document.getElementById("seccode").value; //get the element called seccode
if(!NaN(a) || a<3 || a>4) { // if not a number (varilbe is a), or higher than 3 or 4 then return false and say the alert
return false; 
alert("Please enter a 3-digit security number "); //alert message
}
else return true;
}


//here is someother code that i have been using to test the code 

// function CVV() {		
        // var seccode = document.getElementById("seccode").value;
        // if (LengthCheck(seccode, 3)) { 
		// return false;
        // }
        // else {
			// return true;
            // alert("Please enter a 3-digit security number ");
            
        // }
    // }
	
	
