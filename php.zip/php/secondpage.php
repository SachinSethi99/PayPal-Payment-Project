<!--Sachin Sethi's PHP-->
<!DOCTYPE html>
<html lang="en"> <!--language set as english -->
<head>
<meta charset="utf-8">
	<title>Payment Options</title> <!--the header's title-->
	<link rel='stylesheet' href='css/form-style.css' type='text/css' /><!--link to the css stylesheet-->
	<script src="js/credit-card-master-validation.js"></script><!--link to the javaScript validation-->
</head>

<body onload= 'document.form1.ccnum.focus()' > <!--excute the javaScript -->

<div id="container"><!-- div tag called container for the title section on my html-->
	<h2>You have successfully entred your credit card details</h2><!--title on the page-->
	<hr style= "Border: 2px solid #C8C8C8 "/><!-- the line underneath the title-->
</div>

<div id="container1"><!-- div tag called container for the title section on my html-->
	<h3>Debit / Credit Card <div id ="masterCardimg"> <img src= "img/mastercard.png" width= "15%" height="15%" float="middle"></div> </h3><!-- image of mastercard and subheading-->
</div>
<br>
<div id ="secondPageMessage"> <!-- second page div used for css styling-->
<p1>Your credit card number ends is: <!--message for the user  -->

		
<?php
//connection to the sql database, to the host, username, password, and name of database
$conn = new mysqli("localhost","root","","creditcard");

if ($result = $conn -> query("SELECT * FROM card")) { //seclects the information/record from the card table in the database
while ($row = $result -> fetch_row()) { //fetches the result of the record
$cdnum = $row[1];//now it uses the card number from that stored in row 1, stored as cdnum now
}					
//decodes card number
$cdnum1 = base64_decode($cdnum);
//take the last 4 digits of the card number
$last4 = substr($cdnum, -4,16);
//print to the screen
echo "**** **** **** " . $last4; //shown as **** **** **** 1234, when it appears
$result -> free_result();
}
?></p1> <!-- end of the message -->
</div>

</div>
<div id="container3"> <!--div id for css -->
</body>
</div>
<script src="js/credit-card-master-validation.js"></script> <!--checked through validation-->

</html> <!--end of html -->
